# bmi-calculator-boilerplate
Boilerplate HTML CSS for BMI Calculator  Application
